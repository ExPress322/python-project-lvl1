#!C:\Users\ExPress\AppData\Local\Programs\Python\Python310\python.exe

def main():
    print('Welcome to the Brain Games!')


if __name__ == '__main__':
    main()
